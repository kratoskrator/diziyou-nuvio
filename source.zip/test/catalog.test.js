'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const catalog = require('../src/catalog');
const base = 'https://www.diziyou.one';

test('reads the current category title structure and excludes the alphabetical navigation', () => {
  const html = '<nav><a title="Unrelated" href="/unrelated/">Unrelated</a></nav>' +
    '<div id="categorytitle"><a href="/ornek-dizi/">Örnek &amp; Dizi (2024)</a></div>' +
    '<h2 class="post-title"><a href="/ikinci-dizi/">İkinci Dizi izle</a></h2>' +
    '<div id="categorytitle"><a href="/ornek-dizi/">Örnek &amp; Dizi (2024)</a></div>';
  assert.deepEqual(catalog.parseResults(html, base), [
    { url: base + '/ornek-dizi/', title: 'Örnek & Dizi', type: 'tv', year: 2024 },
    { url: base + '/ikinci-dizi/', title: 'İkinci Dizi', type: 'tv' }
  ]);
});

test('rejects episode, external, credential, unsafe and hidden-comment search links', () => {
  const urls = ['/show-1-sezon-1-bolum/', 'https://ads.test/show/', '//ads.test/show/', 'https://www.diziyou.one@ads.test/show/', 'javascript:alert(1)', 'https://www.diziyou.one\\@ads.test/show/', '/%2f%2fads/'];
  const html = urls.map(url => '<div id="categorytitle"><a href="' + url + '">Show</a></div>').join('') +
    '<!-- <div id="categorytitle"><a href="/hidden/">Hidden</a></div> -->';
  assert.deepEqual(catalog.parseResults(html, base), []);
});

test('ranks only exact metadata titles or original-title slugs', () => {
  const results = [
    { url: base + '/wrong/', title: 'Show Returns', type: 'tv' },
    { url: base + '/show/', title: 'Yerel Başlık', type: 'tv' },
    { url: base + '/yerel/', title: 'Show', type: 'tv' }
  ];
  assert.deepEqual(catalog.rankResults(results, { type: 'tv', title: 'Show' }, 'Show').map(item => item.url), [base + '/yerel/', base + '/show/']);
  assert.deepEqual(catalog.rankResults(results, { type: 'tv', title: 'Unknown' }, 'Show'), []);
  assert.deepEqual(catalog.rankResults(results, { type: 'movie', title: 'Show' }, 'Show'), []);
});

test('uses a supplied result year to distinguish remakes without inventing unavailable years', () => {
  const results = [
    { url: base + '/show-old/', title: 'Show', type: 'tv', year: 1990 },
    { url: base + '/show-new/', title: 'Show', type: 'tv', year: 2024 },
    { url: base + '/show/', title: 'Show', type: 'tv' }
  ];
  assert.deepEqual(catalog.rankResults(results, { title: 'Show', year: 2024 }, 'Show').map(item => item.url), [base + '/show-new/', base + '/show/']);
});

test('selects the requested series and exact episode instead of a sidebar recommendation', () => {
  const html = '<a href="/different-show-1-sezon-2-bolum/">Different show</a>' +
    '<a href="/show-10-sezon-2-bolum/">Wrong season</a>' +
    '<a href="/show-1-sezon-2-bolum/">Right</a>' +
    '<a href="/show-0-sezon-1-bolum/">Special</a>';
  assert.equal(catalog.episodeUrl(html, base + '/show/', 1, 2), base + '/show-1-sezon-2-bolum/');
  assert.equal(catalog.episodeUrl(html, base + '/show/', 0, 1), base + '/show-0-sezon-1-bolum/');
  assert.equal(catalog.episodeUrl(html, base + '/show/', 1, 3), '');
  assert.equal(catalog.episodeUrl(html, base + '/show/', null, 1), '');
});

test('returns no episode when only an external URL or a comment contains it', () => {
  const html = '<a href="https://ads.test/show-1-sezon-1-bolum/">External</a><!-- <a href="/show-1-sezon-1-bolum/">Commented</a> -->';
  assert.equal(catalog.episodeUrl(html, base + '/show/', 1, 1), '');
  assert.equal(catalog.episodeUrl('<p>No links</p>', base + '/show/', 1, 1), '');
});

test('reads only the official iframe and drops autoplay next-episode tracking', () => {
  const html = '<span class="diziyouOption diziyouActivated" id="turkceAltyazili">Türkçe Altyazılı</span>' +
    '<iframe src="https://ads.test/player/1.html"></iframe>' +
    '<iframe id="diziyouPlayer" src="/player/123.html?next=https%3A%2F%2Fsite.test"></iframe>';
  assert.deepEqual(catalog.playerFrames(html, base + '/show-1-sezon-1-bolum/'), [
    { url: base + '/player/123.html', name: 'Türkçe altyazılı', language: 'tr' }
  ]);
  assert.deepEqual(catalog.playerFrames('<iframe id="diziyouPlayer" src="https://ads.test/player/123.html"></iframe>', base), []);
});

test('recognizes an explicitly supplied dubbed player URL', () => {
  assert.deepEqual(catalog.playerFrames('<iframe id="diziyouPlayer" src="/player/123_tr.html"></iframe>', base), [
    { url: base + '/player/123_tr.html', name: 'Türkçe dublaj', language: 'tr' }
  ]);
});

test('adds the actual UI language routes only when their option elements exist', () => {
  const html = '<span id="turkceAltyazili" class="diziyouOption diziyouActivated">Türkçe Altyazılı</span>' +
    '<span id="turkceDublaj" class="diziyouOption">Türkçe Dublaj</span>' +
    '<span id="ingilizceAltyazili" class="diziyouOption">İngilizce Altyazılı</span>' +
    '<iframe id="diziyouPlayer" src="/player/123.html?next=encoded"></iframe>';
  assert.deepEqual(catalog.playerFrames(html, base).map(frame => frame.url), [
    base + '/player/123.html', base + '/player/123_tr.html', base + '/player/123_enSub.html'
  ]);
  assert.equal(catalog.playerFrames('<script>var option="turkceDublaj";</script><iframe id="diziyouPlayer" src="/player/123.html"></iframe>', base).length, 1);
});

test('extracts actual HLS and VTT tracks from the video element while excluding ad scripts', () => {
  const html = '<script>var preroll="https://ads.test/ad.mp4";</script><video id="advertisement"><source src="https://ads.test/ad.mp4"></video>' +
    '<video id="diziyou"><source id="diziyouSource" src="https://storage.media.test/episodes/123/play.m3u8" type="application/x-mpegURL">' +
    '<track kind="subtitles" src="https://storage.media.test/subtitles/123/tr.vtt" srclang="tr" label="Türkçe" default>' +
    '<track kind="subtitles" src="https://storage.media.test/subtitles/123/en.vtt" srclang="en" label="English">' +
    '<track kind="thumbnails" src="https://storage.media.test/thumbs.vtt"></video>';
  assert.deepEqual(catalog.parsePlayer(html, base + '/player/123.html'), [{
    url: 'https://storage.media.test/episodes/123/play.m3u8', type: 'hls', quality: 'Auto', subtitles: [
      { url: 'https://storage.media.test/subtitles/123/tr.vtt', label: 'Türkçe', language: 'tr', default: true },
      { url: 'https://storage.media.test/subtitles/123/en.vtt', label: 'English', language: 'en', default: false }
    ]
  }]);
});

test('resolves actual relative media links, keeps reported quality and rejects unsafe sources', () => {
  const html = '<video id="diziyou"><source src="/video/main.mp4" label="720p">' +
    '<source src="javascript:alert(1)"><source src="https://localhost/private.m3u8">' +
    '<source src="https://127.0.0.1/private.m3u8"><source src="https://cdn.test/page.html">' +
    '<source src="/video/main.mp4" label="720p"><track src="/sub/tr.vtt" srclang="tr"></video>';
  const streams = catalog.parsePlayer(html, base + '/player/1.html');
  assert.equal(streams.length, 1);
  assert.equal(streams[0].url, base + '/video/main.mp4');
  assert.equal(streams[0].quality, '720p');
  assert.equal(streams[0].subtitles[0].url, base + '/sub/tr.vtt');
  assert.deepEqual(catalog.parsePlayer('<script>var url="https://cdn.test/file.m3u8";</script>', base), []);
});

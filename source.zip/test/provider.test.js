'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const code = fs.readFileSync(path.join(__dirname, '../diziyou.js'), 'utf8');
const site = 'https://www.diziyou.one';
const storage = 'https://storage.example.test';
const card = '<div id="categorytitle"><a href="' + site + '/example/">Example</a></div>';
const episode = '<h1>Example 2. Sezon 3. Bölüm</h1><span class="diziyouOption diziyouActivated" id="turkceAltyazili">Türkçe Altyazılı</span><iframe id="diziyouPlayer" src="/player/123.html"></iframe>';
const player = '<video id="diziyou"><source id="diziyouSource" src="' + storage + '/actual.m3u8" type="application/x-mpegURL"><track src="subs/tr.vtt" srclang="tr" label="Türkçe"></video>';
function routes() { return [
  [/^https:\/\/api\.themoviedb\.org\/3\/tv\/99\?/, { name: 'Example', original_name: 'Example', first_air_date: '2020-01-01' }],
  [site + '/?s=Example', card],
  [site + '/example/', '<a href="/other-2-sezon-3-bolum/">Other</a><a href="/example-2-sezon-3-bolum/">Requested</a>'],
  [site + '/example-2-sezon-3-bolum/', episode],
  [site + '/player/123.html', player],
  [storage + '/actual.m3u8', '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=3000000\n720/index.m3u8\n']
]; }
function harness(entries, globals) {
  const requests = [], warnings = [];
  const context = vm.createContext(Object.assign({ module: { exports: {} }, TMDB_API_KEY: 'fixture-only-key', console: { warn: s => warnings.push(s) }, fetch: (url, init) => {
    requests.push({ url, init });
    const entry = entries.find(r => typeof r[0] === 'string' ? r[0] === url : r[0].test(url));
    if (!entry) return Promise.reject(new Error('Unexpected fixture request'));
    const status = entry[2] || 200;
    return Promise.resolve({ status, ok: status >= 200 && status < 300, headers: { get: name => (entry[3] || {})[name] || null }, text: () => Promise.resolve(typeof entry[1] === 'string' ? entry[1] : JSON.stringify(entry[1])) });
  } }, globals || {}));
  vm.runInContext(code, context, { timeout: 1000 });
  return { plugin: context.module.exports, requests, warnings, context };
}

test('bundle resolves exact listed episode, real player URL and subtitles without DOM, Node or timers', async () => {
  const h = harness(routes());
  const streams = await h.plugin.getStreams('99', 'tv', 2, 3);
  assert.equal(streams.length, 1);
  assert.equal(streams[0].url, storage + '/actual.m3u8');
  assert.equal(streams[0].quality, 'Auto');
  assert.equal(streams[0].type, 'hls');
  assert.equal(streams[0].subtitles[0].language, 'tr');
  assert.equal(streams[0].subtitles[0].url, site + '/player/subs/tr.vtt');
  assert.equal(h.warnings.length, 0);
  assert.equal(vm.runInContext('typeof Buffer+","+typeof URL+","+typeof setTimeout', h.context), 'undefined,undefined,undefined');
  assert.ok(!h.requests.some(r => r.url.includes('/other-')));
});

test('invalid or unavailable playlist is omitted', async () => {
  for (const entry of [['<html>Missing</html>', 200], ['Not found', 404]]) {
    const entries = routes(); entries[5] = [storage + '/actual.m3u8', entry[0], entry[1]];
    const h = harness(entries);
    assert.equal((await h.plugin.getStreams('99', 'series', 2, 3)).length, 0);
  }
});

test('403 and 429 stop lookup with a useful log and no retry loop', async () => {
  for (const status of [403, 429]) {
    const entries = routes(); entries[3][2] = status;
    const h = harness(entries);
    assert.equal((await h.plugin.getStreams('99', 'tv', 2, 3)).length, 0);
    assert.equal(h.requests.length, 4);
    assert.match(h.warnings[0], /verification or access restriction/);
    assert.ok(!h.warnings.join(' ').includes('fixture-only-key'));
  }
});

test('movies, malformed ids and invalid episode inputs do not perform network requests', async () => {
  const h = harness([]);
  for (const args of [['99', 'movie'], ['abc', 'tv', 1, 1], ['99', 'tv', 1, 0], ['99', 'tv', -1, 1]]) {
    assert.equal((await h.plugin.getStreams(...args)).length, 0);
  }
  assert.equal(h.requests.length, 0);
});

test('missing exact title and missing requested episode do not return another show or episode', async () => {
  const entries = routes(); entries[2][1] = '<a href="/example-2-sezon-4-bolum/">Wrong episode</a><a href="/other-2-sezon-3-bolum/">Wrong series</a>';
  const h = harness(entries);
  assert.equal((await h.plugin.getStreams('99', 'tv', 2, 3)).length, 0);
  assert.equal(h.requests.length, 3);
  const noMatch = routes(); noMatch[1][1] = '<div id="categorytitle"><a href="/different/">Different</a></div>';
  assert.equal((await harness(noMatch).plugin.getStreams('99', 'tv', 2, 3)).length, 0);
});

test('optional settings override injected key and bearer tokens stay out of query strings', async () => {
  const token = 'fixture-read-token-'.repeat(4);
  const h = harness(routes(), { SCRAPER_SETTINGS: { tmdbApiKey: token } });
  assert.equal((await h.plugin.getStreams('99', 'show', 2, 3)).length, 1);
  assert.equal(h.requests[0].init.headers.Authorization, 'Bearer ' + token);
  assert.ok(!h.requests[0].url.includes(token));
  const fields = await h.plugin.onSettings();
  assert.equal(fields.find(f => f.key === 'tmdbApiKey').isPassword, true);
  const noKey = harness([], { TMDB_API_KEY: '' });
  assert.equal((await noKey.plugin.getStreams('99', 'tv', 2, 3)).length, 0);
  assert.equal(noKey.requests.length, 0);
  assert.match(noKey.warnings[0], /TMDB key unavailable/);
});

test('anonymous cookies are scoped to the site and one lookup', async () => {
  const entries = routes(); entries[1][3] = { 'set-cookie': ['PHPSESSID=fixture-session; Path=/; HttpOnly', '_ct=fixture-csrf; Path=/'] };
  const h = harness(entries);
  await h.plugin.getStreams('99', 'tv', 2, 3);
  assert.match(h.requests[2].init.headers.Cookie, /PHPSESSID=fixture-session/);
  assert.equal(h.requests[5].init.headers.Cookie, undefined);
  await h.plugin.getStreams('99', 'tv', 2, 3);
  assert.equal(h.requests[6].init.headers.Cookie, undefined);
});

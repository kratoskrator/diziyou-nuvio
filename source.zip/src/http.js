'use strict';
var u = require('./utils');
var USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function failure(message, blocked) {
  var error = new Error(message);
  error.providerSafe = true;
  error.siteBlocked = !!blocked;
  return error;
}

// A separate jar per lookup keeps anonymous site sessions out of other providers.
function session() { return { cookies: {} }; }
function saveCookies(response, url, jar) {
  if (!jar || !response.headers || typeof response.headers.get !== 'function') return;
  var raw = response.headers.get('set-cookie');
  if (!raw) return;
  var list = Array.isArray(raw) ? raw : String(raw).split(/,(?=\s*[^;,=\s]+\s*=)/);
  var site = u.origin(url);
  if (!jar.cookies[site]) jar.cookies[site] = {};
  list.forEach(function (entry) {
    var pair = /^\s*([^=;,\s]+)=([^;\r\n]*)/.exec(entry);
    if (pair) jar.cookies[site][pair[1]] = pair[2];
  });
}

function request(url, options) {
  options = options || {};
  if (!/^https?:\/\/[^\s]+$/i.test(url)) return Promise.reject(failure('Unsupported request address.'));
  var site = u.origin(url);
  var headers = { 'User-Agent': USER_AGENT, Accept: options.json ? 'application/json' : 'text/html,application/xhtml+xml,*/*;q=0.8', 'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.8' };
  if (options.referer) headers.Referer = options.referer;
  if (options.origin) headers.Origin = options.origin;
  if (options.bearer) headers.Authorization = 'Bearer ' + options.bearer;
  if (options.body !== undefined) headers['Content-Type'] = 'application/x-www-form-urlencoded';
  var jar = options.session;
  if (jar && jar.cookies[site]) {
    var cookie = Object.keys(jar.cookies[site]).map(function (name) { return name + '=' + jar.cookies[site][name]; }).join('; ');
    if (cookie) headers.Cookie = cookie;
  }
  var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  var timer = null;
  var finished = false;
  return new Promise(function (resolve, reject) {
    function finish(error, value) {
      if (finished) return;
      finished = true;
      if (timer !== null && typeof clearTimeout === 'function') clearTimeout(timer);
      if (error) reject(error); else resolve(value);
    }
    if (typeof setTimeout === 'function') timer = setTimeout(function () {
      finish(failure('Request timed out: ' + site));
      if (controller) controller.abort();
    }, options.timeout || 9000);
    var init = { method: options.body !== undefined ? 'POST' : 'GET', headers: headers };
    if (options.body !== undefined) init.body = options.body;
    if (controller) init.signal = controller.signal;
    Promise.resolve().then(function () { return fetch(url, init); }).then(function (response) {
      saveCookies(response, url, jar);
      if (response.status === 403 || response.status === 429 || response.status === 451) throw failure('Website verification or access restriction (HTTP ' + response.status + '): ' + site + '. A standalone TV plugin cannot complete CAPTCHA verification.', true);
      if (!response.ok) throw failure('HTTP ' + response.status + ': ' + site);
      return response.text();
    }).then(function (body) {
      if (body.length > 1024 * 1024) throw failure('Response exceeds TV size limit: ' + site);
      if (/<title>\s*(?:Just a moment|Attention Required|Doğrulama gerekiyor)/i.test(body) || /cf-browser-verification|class=["']cf-turnstile/i.test(body)) throw failure('Website CAPTCHA verification required: ' + site, true);
      if (!options.json) return finish(null, body);
      var value;
      try { value = JSON.parse(body); } catch (ignored) { throw failure('Invalid JSON response: ' + site); }
      finish(null, value);
    }).catch(function (error) { finish(error && error.providerSafe ? error : failure('Network request failed: ' + site)); });
  });
}

module.exports = { request: request, USER_AGENT: USER_AGENT, session: session };


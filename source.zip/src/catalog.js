'use strict';
var u = require('./utils');

function readableHtml(value) {
  return typeof value === 'string' && value.length <= 4 * 1024 * 1024 ? value.replace(/<!--[\s\S]*?-->/g, '') : '';
}

function safeUrl(value, base) {
  value = String(value || '');
  if (!value || /[\\\x00-\x20\x7f]/.test(value)) return '';
  var url = u.absolute(value, base);
  var host = /^https:\/\/([a-z0-9.-]+)(?::\d+)?(?:[/?#]|$)/i.exec(url);
  if (!host || /(?:^|\.)localhost\.?$/i.test(host[1]) || /^(?:127\.|10\.|192\.168\.|169\.254\.|0\.)/.test(host[1]) || /^172\.(?:1[6-9]|2\d|3[01])\./.test(host[1])) return '';
  return url;
}

function localUrl(value, base) {
  var url = safeUrl(value, base);
  if (!url || !u.sameSite(url, base)) return '';
  url = url.split(/[?#]/)[0];
  return /%(?:2f|5c|00|0a|0d)/i.test(url) ? '' : url;
}

function pageSlug(value) {
  var path = String(value || '').slice(u.origin(value).length).split(/[?#]/)[0];
  var match = /^\/([a-z0-9][a-z0-9_-]*)\/?$/i.exec(path);
  return match ? match[1] : '';
}

function yearValue(value) {
  var match = /\b((?:19|20)\d{2})\b/.exec(String(value || ''));
  return match ? Number(match[1]) : null;
}

function cleanTitle(value) {
  return u.text(value).replace(/[\u200e\u200f]/g, '').replace(/\s+izle\s*$/i, '').replace(/\s*\((?:19|20)\d{2}\)\s*$/, '').trim();
}

function titleContainers(html) {
  var results = [];
  var opening = /<([a-z][\w:-]*)\b([^>]*)>/gi;
  var match;
  while ((match = opening.exec(html)) !== null) {
    var id = u.attr(match[2], 'id');
    var classes = ' ' + u.attr(match[2], 'class').replace(/\s+/g, ' ') + ' ';
    if (id !== 'categorytitle' && classes.indexOf(' post-title ') === -1 && classes.indexOf(' entry-title ') === -1) continue;
    var closing = new RegExp('^([\\s\\S]*?)<\\/' + match[1] + '\\s*>', 'i');
    var body = closing.exec(html.slice(opening.lastIndex));
    if (body) results.push(body[1]);
    if (results.length >= 80) break;
  }
  return results;
}

function parseResults(html, base) {
  var result = [];
  var seen = {};
  titleContainers(readableHtml(html)).forEach(function (body) {
    var anchors = /<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi;
    var match;
    while ((match = anchors.exec(body)) !== null) {
      var url = localUrl(u.attr(match[1], 'href'), base);
      var slug = pageSlug(url);
      var rawTitle = u.text(match[2]) || u.attr(match[1], 'title');
      var title = cleanTitle(rawTitle);
      if (!url || !slug || /-\d+-sezon-\d+-bolum$/i.test(slug) || !title || seen[url]) continue;
      seen[url] = true;
      var item = { url: url, title: title, type: 'tv' };
      var yearMatch = /\((\d{4})\)\s*(?:izle)?\s*$/i.exec(rawTitle);
      var year = yearMatch ? yearValue(yearMatch[1]) : null;
      if (year) item.year = year;
      result.push(item);
    }
  });
  return result;
}

function titleList(metadata) {
  var titles = [metadata.title, metadata.originalTitle, metadata.turkishTitle];
  if (Array.isArray(metadata.titles)) titles = titles.concat(metadata.titles);
  return titles.filter(function (value) { return typeof value === 'string' && value; }).map(function (value) { return u.normalize(cleanTitle(value)); });
}

function rankResults(results, metadata, query) {
  metadata = metadata || {};
  if (metadata.type && metadata.type !== 'tv' && metadata.type !== 'series') return [];
  var titles = titleList(metadata);
  var queryTitle = typeof query === 'string' ? u.normalize(cleanTitle(query)) : '';
  var targetYear = yearValue(metadata.year);
  return (Array.isArray(results) ? results : []).map(function (item, index) {
    if (!item || item.type !== 'tv') return null;
    var title = u.normalize(cleanTitle(item.title));
    var slug = u.normalize(pageSlug(item.url));
    var exactTitle = titles.indexOf(title) !== -1;
    var exactSlug = titles.indexOf(slug) !== -1;
    if (!exactTitle && !exactSlug) return null;
    if (targetYear && item.year && Math.abs(targetYear - item.year) > 1) return null;
    return { item: item, score: (exactTitle ? 100 : 0) + (exactSlug ? 80 : 0) + (title === queryTitle ? 10 : 0) + (targetYear && targetYear === item.year ? 200 : 0), index: index };
  }).filter(Boolean).sort(function (a, b) { return b.score - a.score || a.index - b.index; }).map(function (entry) { return entry.item; });
}

function integer(value) {
  return value != null && /^\d+$/.test(String(value).trim()) ? Number(value) : null;
}

function episodeUrl(html, seriesUrl, season, episode) {
  var wantedSeason = integer(season);
  var wantedEpisode = integer(episode);
  var series = pageSlug(seriesUrl).replace(/-\d+-sezon-\d+-bolum$/i, '');
  if (!series || wantedSeason === null || wantedEpisode === null) return '';
  var anchors = /<a\b[^>]*>/gi;
  var match;
  html = readableHtml(html);
  while ((match = anchors.exec(html)) !== null) {
    var url = localUrl(u.attr(match[0], 'href'), seriesUrl);
    var numbers = /^(.*)-(\d+)-sezon-(\d+)-bolum$/i.exec(pageSlug(url));
    if (numbers && numbers[1].toLowerCase() === series.toLowerCase() && Number(numbers[2]) === wantedSeason && Number(numbers[3]) === wantedEpisode) return url;
  }
  return '';
}

function frameName(html, url) {
  if (/_tr\.html(?:[?#]|$)/i.test(url)) return { name: 'Türkçe dublaj', language: 'tr' };
  if (/_enSub\.html(?:[?#]|$)/i.test(url)) return { name: 'İngilizce altyazılı', language: 'en' };
  var options = /<[^>]+\bid\s*=\s*(?:"(turkceAltyazili|turkceDublaj|ingilizceAltyazili)"|'(turkceAltyazili|turkceDublaj|ingilizceAltyazili)')[^>]*>/gi;
  var match;
  while ((match = options.exec(html)) !== null) {
    if ((' ' + u.attr(match[0], 'class') + ' ').indexOf(' diziyouActivated ') === -1) continue;
    var id = match[1] || match[2];
    if (id === 'turkceDublaj') return { name: 'Türkçe dublaj', language: 'tr' };
    if (id === 'ingilizceAltyazili') return { name: 'İngilizce altyazılı', language: 'en' };
    return { name: 'Türkçe altyazılı', language: 'tr' };
  }
  return { name: 'Orijinal ses', language: 'original' };
}

function playerFrames(html, pageUrl) {
  html = readableHtml(html);
  var frames = html.match(/<iframe\b[^>]*>/gi) || [];
  var result = [];
  var seen = {};
  frames.forEach(function (tag) {
    if (u.attr(tag, 'id') !== 'diziyouPlayer') return;
    var url = localUrl(u.attr(tag, 'src') || u.attr(tag, 'data-src'), pageUrl);
    var path = url.slice(u.origin(url).length);
    if (!/^\/player\/[a-z0-9_-]+\.html$/i.test(path) || seen[url]) return;
    seen[url] = true;
    var label = frameName(html, url);
    result.push({ url: url, name: label.name, language: label.language });
    var playerId = /^\/player\/(\d+)(?:_tr|_enSub)?\.html$/i.exec(path);
    if (!playerId) return;
    var options = html.match(/<(?:span|a|button|option)\b[^>]*>/gi) || [];
    options.forEach(function (option) {
      var id = u.attr(option, 'id');
      var suffix = id === 'turkceDublaj' ? '_tr' : id === 'ingilizceAltyazili' ? '_enSub' : '';
      if (!suffix) return;
      // These language routes are the same replacements used by the public site's UI.
      var alternate = u.origin(url) + '/player/' + playerId[1] + suffix + '.html';
      if (seen[alternate]) return;
      seen[alternate] = true;
      var alternateLabel = frameName('', alternate);
      result.push({ url: alternate, name: alternateLabel.name, language: alternateLabel.language });
    });
  });
  return result;
}

function parsePlayer(html, frameUrl) {
  html = readableHtml(html);
  // Read the actual video element only: preroll and advertising scripts contain other URLs.
  var videos = /<video\b([^>]*)>([\s\S]*?)<\/video\s*>/gi;
  var match;
  var video;
  while ((match = videos.exec(html)) !== null) {
    if (u.attr(match[1], 'id') === 'diziyou') { video = match; break; }
  }
  if (!video) return [];
  var subtitles = [];
  var subSeen = {};
  var tracks = video[2].match(/<track\b[^>]*>/gi) || [];
  tracks.forEach(function (tag) {
    var kind = u.attr(tag, 'kind');
    if (kind && !/^(?:subtitles|captions)$/i.test(kind)) return;
    var url = safeUrl(u.attr(tag, 'src'), frameUrl);
    if (!url || !/\.vtt(?:[?#]|$)/i.test(url) || subSeen[url]) return;
    subSeen[url] = true;
    var language = u.attr(tag, 'srclang') || 'und';
    subtitles.push({ url: url, label: u.attr(tag, 'label') || language, language: language, default: /\sdefault(?:\s|=|\/?>)/i.test(tag) });
  });
  var sources = video[2].match(/<source\b[^>]*>/gi) || [];
  if (u.attr(video[1], 'src')) sources.unshift('<source src="' + u.attr(video[1], 'src').replace(/"/g, '&quot;') + '">');
  var streams = [];
  var seen = {};
  sources.forEach(function (tag) {
    var url = safeUrl(u.attr(tag, 'src'), frameUrl);
    var extension = /\.(m3u8|mp4)(?:[?#]|$)/i.exec(url);
    if (!url || !extension || seen[url]) return;
    seen[url] = true;
    var quality = u.attr(tag, 'label') || u.attr(tag, 'res') || u.attr(tag, 'size');
    if (!/^(?:\d{3,4}p?|auto)$/i.test(quality)) quality = 'Auto';
    streams.push({ url: url, type: extension[1].toLowerCase() === 'm3u8' ? 'hls' : 'mp4', quality: quality, subtitles: subtitles.slice() });
  });
  return streams;
}

module.exports = { parseResults: parseResults, rankResults: rankResults, episodeUrl: episodeUrl, playerFrames: playerFrames, parsePlayer: parsePlayer };

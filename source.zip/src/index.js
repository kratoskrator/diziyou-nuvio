'use strict';
var u = require('./utils');
var http = require('./http');
var catalog = require('./catalog');
var DEFAULT_SITE = 'https://www.diziyou.one';

function settings() {
  var root = typeof globalThis !== 'undefined' ? globalThis : {};
  var saved = root.SCRAPER_SETTINGS || {};
  return { site: u.siteUrl(saved.siteUrl || DEFAULT_SITE) || DEFAULT_SITE, key: String(saved.tmdbApiKey || root.TMDB_API_KEY || '').trim(), session: http.session() };
}

function metadata(id, cfg) {
  if (!cfg.key) return Promise.reject(new Error('TMDB key unavailable. Enter your own key in DiziYou TV settings.'));
  var token = cfg.key.length > 40;
  var url = 'https://api.themoviedb.org/3/tv/' + encodeURIComponent(id) + '?language=tr-TR';
  if (!token) url += '&api_key=' + encodeURIComponent(cfg.key);
  return http.request(url, { json: true, bearer: token ? cfg.key : '' }).then(function (data) {
    return { title: data.name || '', originalTitle: data.original_name || '', year: Number(String(data.first_air_date || '').slice(0, 4)) || null };
  });
}

function search(meta, cfg) {
  var queries = [meta.title, meta.originalTitle].filter(function (value, index, all) { return value && all.indexOf(value) === index; });
  function next(index) {
    if (index >= queries.length) return Promise.resolve([]);
    var query = queries[index];
    return http.request(cfg.site + '/?s=' + encodeURIComponent(query), { referer: cfg.site + '/', session: cfg.session }).then(function (html) {
      var matches = catalog.rankResults(catalog.parseResults(html, cfg.site), meta, query);
      return matches.length ? matches.slice(0, 2) : next(index + 1);
    });
  }
  return next(0);
}

function resolveEpisode(page, meta, cfg, season, episode) {
  var frames = catalog.playerFrames(page.html, page.url).slice(0, 2);
  return Promise.all(frames.map(function (frame) {
    return http.request(frame.url, { referer: page.url, session: cfg.session }).then(function (body) {
      var parsed = catalog.parsePlayer(body, frame.url).filter(function (stream) { return stream.type === 'hls'; }).slice(0, 2);
      return Promise.all(parsed.map(function (stream) {
        return http.request(stream.url, { referer: cfg.site + '/', origin: cfg.site }).then(function (playlist) {
          // A visible player can still point at an expired, missing or blocked file.
          if (!/^\s*#EXTM3U(?:\r?\n|$)/.test(playlist)) return null;
          var headers = { Referer: cfg.site + '/', Origin: cfg.site, 'User-Agent': http.USER_AGENT };
          var subtitles = (stream.subtitles || []).map(function (sub, index) {
            return { id: 'diziyou-' + index, url: sub.url, language: sub.language || 'und', name: sub.label || sub.name || sub.language || 'Subtitle', headers: headers };
          });
          return { name: 'DiziYou TV', provider: 'DiziYou TV', title: meta.title + ' S' + season + 'E' + episode + ' | ' + (frame.name || 'Original audio'), url: stream.url, quality: stream.quality || 'Auto', type: 'hls', headers: headers, subtitles: subtitles };
        }).catch(function (error) { console.warn('[DiziYou TV] ' + error.message); return null; });
      }));
    }).catch(function (error) { console.warn('[DiziYou TV] ' + error.message); return []; });
  })).then(function (groups) {
    var streams = [];
    groups.forEach(function (group) { group.forEach(function (stream) { if (stream) streams.push(stream); }); });
    return streams;
  });
}

function getStreams(tmdbId, mediaType, season, episode) {
  if (mediaType !== 'tv' && mediaType !== 'series' && mediaType !== 'show') return Promise.resolve([]);
  if (!/^\d+$/.test(String(tmdbId)) || !/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(episode) < 1) return Promise.resolve([]);
  var cfg = settings();
  return metadata(tmdbId, cfg).then(function (meta) {
    return search(meta, cfg).then(function (matches) {
      function next(index) {
        if (index >= matches.length) return Promise.resolve([]);
        var match = matches[index];
        return http.request(match.url, { referer: cfg.site + '/', session: cfg.session }).then(function (html) {
          var target = catalog.episodeUrl(html, match.url, season, episode);
          if (!target) return [];
          return http.request(target, { referer: match.url, session: cfg.session }).then(function (body) {
            return resolveEpisode({ html: body, url: target }, meta, cfg, season, episode);
          });
        }).then(function (streams) { return streams.length ? streams : next(index + 1); });
      }
      return next(0);
    });
  }).then(function (streams) {
    var seen = {};
    return streams.filter(function (stream) { if (seen[stream.url]) return false; seen[stream.url] = true; return true; });
  }).catch(function (error) {
    console.warn('[DiziYou TV] ' + error.message);
    return [];
  });
}

function onSettings() {
  return Promise.resolve([
    { type: 'header', label: 'DiziYou TV' },
    { type: 'text', key: 'siteUrl', label: 'Website address', defaultValue: DEFAULT_SITE, description: 'Update this HTTPS origin if the website moves.' },
    { type: 'text', key: 'tmdbApiKey', label: 'TMDB API key (optional)', isPassword: true, defaultValue: '', description: 'Uses Nuvio\'s key when available. Otherwise enter your own v3 key or API Read Access Token.' }
  ]);
}

module.exports = { getStreams: getStreams, onSettings: onSettings };

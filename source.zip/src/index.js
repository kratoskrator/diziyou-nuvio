'use strict';
var u = require('./utils');
var http = require('./http');
var catalog = require('./catalog');
var media = require('./media');
var DEFAULT_SITE = 'https://www.diziyou.one';

function settings() {
  var root = typeof globalThis !== 'undefined' ? globalThis : {};
  var saved = root.SCRAPER_SETTINGS || {};
  return { site: u.siteUrl(saved.siteUrl || DEFAULT_SITE) || DEFAULT_SITE, key: String(saved.tmdbApiKey || root.TMDB_API_KEY || '').trim(), audio: /^(?:tr|turkish)$/i.test(String(saved.audioPreference || '')) ? 'tr' : 'original', session: http.session() };
}

function metadata(id, cfg) {
  if (!cfg.key) return Promise.reject(new Error('TMDB key unavailable. Enter your own key in DiziYou TV settings.'));
  var token = cfg.key.length > 40;
  var url = 'https://api.themoviedb.org/3/tv/' + encodeURIComponent(id) + '?language=tr-TR';
  if (!token) url += '&api_key=' + encodeURIComponent(cfg.key);
  return http.request(url, { json: true, bearer: token ? cfg.key : '', session: cfg.session }).then(function (data) {
    return { title: data.name || '', originalTitle: data.original_name || '', year: Number(String(data.first_air_date || '').slice(0, 4)) || null };
  });
}

function search(meta, cfg) {
  var queries = [meta.title, meta.originalTitle].filter(function (value, index, all) { return value && all.indexOf(value) === index; });
  function next(index) {
    if (index >= queries.length) return Promise.resolve([]);
    var query = queries[index];
    return http.request(cfg.site + '/?s=' + encodeURIComponent(query), { referer: cfg.site + '/', session: cfg.session }).then(function (html) {
      var matches = catalog.rankResults(catalog.parseResults(html, cfg.site), meta, query);
      return matches.length ? matches.slice(0, 2) : next(index + 1);
    }).catch(function (error) {
      if (error.siteBlocked || /budget exhausted/i.test(error.message || '')) throw error;
      return next(index + 1);
    });
  }
  return next(0);
}

function firstSource(tasks, preferFirst) {
  if (!tasks.length) return Promise.resolve([]);
  return new Promise(function (resolve) {
    var results = [], completed = [], remaining = tasks.length, finished = false;
    tasks.forEach(function (task, index) {
      Promise.resolve().then(task).catch(function () { return []; }).then(function (streams) {
        results[index] = streams || []; completed[index] = true; remaining--;
        if (finished) return;
        // Preserve the selected audio. An unused, slower language must not hold
        // its verified preferred source; fall back after that preference fails.
        if (preferFirst && !completed[0]) return;
        for (var i = 0; i < results.length; i++) if (results[i] && results[i].length) { finished = true; resolve(results[i]); return; }
        if (!remaining) { finished = true; resolve([]); }
      });
    });
  });
}

function resolveEpisode(page, meta, cfg, season, episode) {
  var frames = catalog.playerFrames(page.html, page.url);
  function preferred(frame) { var dub = /dublaj/i.test(frame.name); return cfg.audio === 'tr' ? dub : !dub; }
  // English-subtitle and Turkish-subtitle frames can point at the same original
  // audio. Keep a dubbed choice in the bounded pair when the site publishes it.
  var originals = frames.filter(function (frame) { return !/dublaj/i.test(frame.name); });
  var dubbed = frames.filter(function (frame) { return /dublaj/i.test(frame.name); });
  frames = originals.length && dubbed.length ? [originals[0], dubbed[0]] : frames.slice(0, 2);
  frames.sort(function (a, b) { return Number(preferred(b)) - Number(preferred(a)); });
  return firstSource(frames.slice(0, 2).map(function (frame) {
    return function () { return http.request(frame.url, { referer: page.url, session: cfg.session, responseInfo: true }).then(function (response) {
      if (!u.sameSite(response.finalUrl, frame.url) || response.finalUrl.split(/[?#]/)[0] !== frame.url.split(/[?#]/)[0]) return [];
      var parsed = catalog.parsePlayer(response.body, response.finalUrl).filter(function (stream) { return stream.type === 'hls'; }).slice(0, 2);
      return firstSource(parsed.map(function (stream) {
        return function () { return http.request(stream.url, { referer: cfg.site + '/', origin: cfg.site, session: cfg.session }).then(function (playlist) {
          var info = media.hls(playlist);
          if (!info) return [];
          var headers = { Referer: cfg.site + '/', Origin: cfg.site, 'User-Agent': http.USER_AGENT };
          var subtitles = (stream.subtitles || []).map(function (sub, index) {
            return { id: 'diziyou-' + index, url: sub.url, language: sub.language || 'und', name: sub.label || sub.name || sub.language || 'Subtitle', headers: headers };
          });
          return [{ name: 'DiziYou TV', provider: 'DiziYou TV', title: meta.title + ' S' + season + 'E' + episode + ' | ' + (frame.name || 'Original audio'), url: stream.url, quality: info.quality || 'Auto', type: 'hls', headers: headers, subtitles: subtitles }];
        }).catch(function () { return []; }); };
      }), false);
    }).catch(function () { return []; }); };
  }), true);
}

function getStreams(tmdbId, mediaType, season, episode) {
  if (mediaType !== 'tv' && mediaType !== 'series' && mediaType !== 'show') return Promise.resolve([]);
  if (!/^\d+$/.test(String(tmdbId)) || !/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(episode) < 1) return Promise.resolve([]);
  var cfg = settings();
  return metadata(tmdbId, cfg).then(function (meta) {
    return search(meta, cfg).then(function (matches) {
      function next(index) {
        if (index >= matches.length) return Promise.resolve([]);
        var match = matches[index];
        return http.request(match.url, { referer: cfg.site + '/', session: cfg.session }).then(function (html) {
          var target = catalog.episodeUrl(html, match.url, season, episode);
          if (!target) return [];
          return http.request(target, { referer: match.url, session: cfg.session }).then(function (body) {
            return resolveEpisode({ html: body, url: target }, meta, cfg, season, episode);
          });
        }).then(function (streams) { return streams.length ? streams : next(index + 1); }).catch(function (error) {
          if (error.siteBlocked || /budget exhausted/i.test(error.message || '')) throw error;
          return next(index + 1);
        });
      }
      return next(0);
    });
  }).then(function (streams) {
    http.cancel(cfg.session);
    var seen = {};
    return streams.filter(function (stream) { if (seen[stream.url]) return false; seen[stream.url] = true; return true; });
  }).catch(function (error) {
    http.cancel(cfg.session);
    console.warn('[DiziYou TV] ' + (error.providerSafe ? error.message : !cfg.key ? 'TMDB key unavailable. Enter your own key in plugin settings.' : 'Source could not be resolved.'));
    return [];
  });
}

function onSettings() {
  return Promise.resolve([
    { type: 'header', label: 'DiziYou TV' },
    { type: 'text', key: 'audioPreference', label: 'Audio language', defaultValue: 'original', description: 'Enter original for original/subtitled audio, or tr for Turkish dubbing. Falls back when unavailable.' },
    { type: 'text', key: 'siteUrl', label: 'Website address', defaultValue: DEFAULT_SITE, description: 'Update this HTTPS origin if the website moves.' },
    { type: 'text', key: 'tmdbApiKey', label: 'TMDB API key (optional)', isPassword: true, defaultValue: '', description: 'Uses Nuvio\'s key when available. Otherwise enter your own v3 key or API Read Access Token.' }
  ]);
}

module.exports = { getStreams: getStreams, onSettings: onSettings };
